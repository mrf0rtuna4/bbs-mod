package mchorse.bbs_mod.ui.framework.elements.events;

import mchorse.bbs_mod.ui.framework.elements.UIElement;

public class UIAddedEvent extends UIEvent
{
    public UIAddedEvent(UIElement element)
    {
        super(element);
    }
}