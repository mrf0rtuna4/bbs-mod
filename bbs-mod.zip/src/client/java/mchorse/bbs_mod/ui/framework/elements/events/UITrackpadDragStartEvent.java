package mchorse.bbs_mod.ui.framework.elements.events;

import mchorse.bbs_mod.ui.framework.elements.input.UITrackpad;

public class UITrackpadDragStartEvent extends UIEvent<UITrackpad>
{
    public UITrackpadDragStartEvent(UITrackpad element)
    {
        super(element);
    }
}