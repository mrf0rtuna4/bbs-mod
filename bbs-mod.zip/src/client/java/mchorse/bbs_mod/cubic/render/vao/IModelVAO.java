package mchorse.bbs_mod.cubic.render.vao;

public interface IModelVAO
{
    public void render();
}