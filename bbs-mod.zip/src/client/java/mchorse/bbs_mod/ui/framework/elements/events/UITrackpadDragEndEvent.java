package mchorse.bbs_mod.ui.framework.elements.events;

import mchorse.bbs_mod.ui.framework.elements.input.UITrackpad;

public class UITrackpadDragEndEvent extends UIEvent<UITrackpad>
{
    public UITrackpadDragEndEvent(UITrackpad element)
    {
        super(element);
    }
}