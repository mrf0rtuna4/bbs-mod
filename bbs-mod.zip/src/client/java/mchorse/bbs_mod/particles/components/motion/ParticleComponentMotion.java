package mchorse.bbs_mod.particles.components.motion;

import mchorse.bbs_mod.particles.components.ParticleComponentBase;

public abstract class ParticleComponentMotion extends ParticleComponentBase
{}