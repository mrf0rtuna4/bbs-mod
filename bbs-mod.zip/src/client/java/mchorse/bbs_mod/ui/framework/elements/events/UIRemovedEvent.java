package mchorse.bbs_mod.ui.framework.elements.events;

import mchorse.bbs_mod.ui.framework.elements.UIElement;

public class UIRemovedEvent extends UIEvent
{
    public UIRemovedEvent(UIElement element)
    {
        super(element);
    }
}