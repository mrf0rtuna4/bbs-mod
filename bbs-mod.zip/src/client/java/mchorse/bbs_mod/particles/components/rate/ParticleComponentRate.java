package mchorse.bbs_mod.particles.components.rate;

import mchorse.bbs_mod.math.molang.expressions.MolangExpression;
import mchorse.bbs_mod.particles.components.ParticleComponentBase;

public abstract class ParticleComponentRate extends ParticleComponentBase
{
    public MolangExpression particles;
}