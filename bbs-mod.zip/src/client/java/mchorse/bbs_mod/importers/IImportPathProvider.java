package mchorse.bbs_mod.importers;

import java.io.File;

public interface IImportPathProvider
{
    public File getImporterPath();
}