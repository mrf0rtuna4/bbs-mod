package mchorse.bbs_mod.cubic.render.vao;

public record ModelVAOData(float[] vertices, float[] normals, float[] tangents, float[] texCoords)
{}