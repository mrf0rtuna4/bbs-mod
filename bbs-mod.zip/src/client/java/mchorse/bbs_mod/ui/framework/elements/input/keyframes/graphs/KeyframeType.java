package mchorse.bbs_mod.ui.framework.elements.input.keyframes.graphs;

public enum KeyframeType
{
    REGULAR, LEFT_HANDLE, RIGHT_HANDLE;
}