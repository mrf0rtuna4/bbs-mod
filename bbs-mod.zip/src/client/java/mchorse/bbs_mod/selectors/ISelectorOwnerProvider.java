package mchorse.bbs_mod.selectors;

public interface ISelectorOwnerProvider
{
    public SelectorOwner getOwner();
}