package mchorse.bbs_mod.particles.components;

public interface IComponentBase
{
	public default int getSortingIndex()
	{
		return 0;
	}
}