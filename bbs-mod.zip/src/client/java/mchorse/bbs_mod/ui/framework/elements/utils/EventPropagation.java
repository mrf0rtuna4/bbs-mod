package mchorse.bbs_mod.ui.framework.elements.utils;

public enum EventPropagation
{
    PASS, BLOCK, BLOCK_INSIDE;
}