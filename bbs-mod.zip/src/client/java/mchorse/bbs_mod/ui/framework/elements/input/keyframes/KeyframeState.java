package mchorse.bbs_mod.ui.framework.elements.input.keyframes;

import mchorse.bbs_mod.data.types.MapType;

import java.util.ArrayList;
import java.util.List;

public class KeyframeState
{
    public List<List<Integer>> selected = new ArrayList<>();
    public MapType extra = new MapType();
}
