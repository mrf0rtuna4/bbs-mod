package mchorse.bbs_mod.graphics.texture;

public interface ITexture
{
    public int getId();
}