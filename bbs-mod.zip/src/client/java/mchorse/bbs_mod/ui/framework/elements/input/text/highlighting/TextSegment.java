package mchorse.bbs_mod.ui.framework.elements.input.text.highlighting;

public class TextSegment
{
    public String text;
    public int color;
    public int width;

    public TextSegment(String text, int color, int width)
    {
        this.text = text;
        this.color = color;
        this.width = width;
    }
}