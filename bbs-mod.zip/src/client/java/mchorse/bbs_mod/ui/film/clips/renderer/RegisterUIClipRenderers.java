package mchorse.bbs_mod.ui.film.clips.renderer;

public class RegisterUIClipRenderers
{
    public final UIClipRenderers renderers;

    public RegisterUIClipRenderers(UIClipRenderers renderers)
    {
        this.renderers = renderers;
    }
}