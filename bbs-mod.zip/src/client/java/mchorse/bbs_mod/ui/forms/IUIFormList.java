package mchorse.bbs_mod.ui.forms;

import mchorse.bbs_mod.forms.forms.Form;

public interface IUIFormList
{
    public void exit();

    public void toggleEditor();

    public void accept(Form form);
}