package mchorse.bbs_mod.ui.framework.elements.events;

import mchorse.bbs_mod.ui.framework.elements.overlay.UIOverlayPanel;

public class UIOverlayCloseEvent extends UIEvent<UIOverlayPanel>
{
    public UIOverlayCloseEvent(UIOverlayPanel element)
    {
        super(element);
    }
}