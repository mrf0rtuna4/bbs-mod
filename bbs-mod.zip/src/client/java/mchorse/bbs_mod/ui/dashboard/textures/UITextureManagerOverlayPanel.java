package mchorse.bbs_mod.ui.dashboard.textures;

import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.BBSModClient;
import mchorse.bbs_mod.BBSSettings;
import mchorse.bbs_mod.graphics.texture.Texture;
import mchorse.bbs_mod.graphics.window.Window;
import mchorse.bbs_mod.l10n.keys.IKey;
import mchorse.bbs_mod.resources.Link;
import mchorse.bbs_mod.ui.UIKeys;
import mchorse.bbs_mod.ui.framework.UIContext;
import mchorse.bbs_mod.ui.framework.elements.buttons.UIIcon;
import mchorse.bbs_mod.ui.framework.elements.input.list.UILinkList;
import mchorse.bbs_mod.ui.framework.elements.input.list.UISearchList;
import mchorse.bbs_mod.ui.framework.elements.overlay.UIConfirmOverlayPanel;
import mchorse.bbs_mod.ui.framework.elements.overlay.UIMessageFolderOverlayPanel;
import mchorse.bbs_mod.ui.framework.elements.overlay.UIMessageOverlayPanel;
import mchorse.bbs_mod.ui.framework.elements.overlay.UIOverlay;
import mchorse.bbs_mod.ui.framework.elements.overlay.UIOverlayPanel;
import mchorse.bbs_mod.ui.utils.icons.Icons;
import mchorse.bbs_mod.utils.Direction;
import mchorse.bbs_mod.utils.PNGEncoder;
import mchorse.bbs_mod.utils.StringUtils;
import mchorse.bbs_mod.utils.colors.Colors;
import mchorse.bbs_mod.utils.resources.Pixels;
import org.lwjgl.opengl.GL11;

import java.io.File;

public class UITextureManagerOverlayPanel extends UIOverlayPanel
{
    public UIIcon linear;
    public UIIcon copy;
    public UIIcon export;
    public UIIcon refresh;
    public UIIcon extractFrames;

    public UISearchList<Link> textures;

    private UITextureManagerPanel panel;
    private File exportFolder;

    public boolean linkLinear;

    public static File getFirstAvailableFile(File folder, String name)
    {
        File file = new File(folder, name + ".png");
        int index = 0;

        while (file.exists())
        {
            index += 1;
            file = new File(folder, name + index + ".png");
        }

        return file;
    }

    public UITextureManagerOverlayPanel(IKey title, UITextureManagerPanel panel)
    {
        super(title);

        this.panel = panel;
        this.exportFolder = BBSMod.getExportFolder();

        this.textures = new UISearchList<>(new UILinkList((rl) ->
        {
            if (this.panel.viewer.isDirty())
            {
                UIOverlay.addOverlay(this.getContext(), new UIConfirmOverlayPanel(
                    UIKeys.TEXTURES_DISCARD_TITLE,
                    UIKeys.TEXTURES_DISCARD_DESCRIPTION,
                    (confirm) -> this.panel.pickLink(confirm ? rl.get(0) : this.panel.viewer.getTexture())
                ));
            }
            else
            {
                this.panel.pickLink(rl.get(0));
            }
        }));
        this.textures.label(UIKeys.GENERAL_SEARCH);
        this.textures.full(this.content).x(6).w(1F, -12);

        this.linear = new UIIcon(Icons.GRAPH, (b) -> this.toggleLinear());
        this.linear.tooltip(UIKeys.TEXTURES_LINEAR, Direction.LEFT);
        this.copy = new UIIcon(Icons.COPY, (b) -> this.copy());
        this.copy.tooltip(UIKeys.TEXTURES_COPY, Direction.LEFT);
        this.export = new UIIcon(Icons.EXTERNAL, (b) -> this.export());
        this.export.tooltip(UIKeys.TEXTURES_EXPORT, Direction.LEFT);
        this.refresh = new UIIcon(Icons.REFRESH, (b) -> this.remove());
        this.refresh.tooltip(UIKeys.TEXTURES_REFRESH, Direction.LEFT);
        this.extractFrames = new UIIcon(Icons.UPLOAD, (b) -> this.extractFrames());
        this.extractFrames.tooltip(UIKeys.TEXTURES_EXTRACT_FRAMES_TITLE, Direction.LEFT);

        this.icons.add(this.linear, this.copy, this.export, this.refresh, this.extractFrames);
        this.content.add(this.textures);
    }

    private void toggleLinear()
    {
        Texture texture = BBSModClient.getTextures().getTexture(this.panel.getLink());

        this.linkLinear = !this.linkLinear;

        texture.bind();
        texture.setFilter(this.linkLinear ? GL11.GL_LINEAR : GL11.GL_NEAREST);
    }

    private void copy()
    {
        Link link = this.textures.list.getCurrentFirst();

        if (link == null)
        {
            return;
        }

        Window.setClipboard(link.toString());
    }

    private void export()
    {
        Link link = this.textures.list.getCurrentFirst();

        if (link == null)
        {
            return;
        }

        String name = StringUtils.removeExtension(StringUtils.fileName(link.path));
        File folder = this.exportFolder;
        File file = getFirstAvailableFile(folder, name);

        folder.mkdirs();

        Pixels pixels = this.panel.viewer.getPixels();

        try
        {
            PNGEncoder.writeToFile(pixels, file);
            UIMessageFolderOverlayPanel panel = new UIMessageFolderOverlayPanel(
                UIKeys.TEXTURES_EXPORT_OVERLAY_TITLE,
                UIKeys.TEXTURES_EXPORT_OVERLAY_SUCCESS.format(file.getName()),
                this.exportFolder
            );

            panel.folder.tooltip(UIKeys.TEXTURES_EXPORT_OVERLAY_OPEN_FOLDER, Direction.LEFT);

            UIOverlay.addOverlay(this.getContext(), panel);
        }
        catch (Exception e)
        {
            e.printStackTrace();

            UIOverlay.addOverlay(this.getContext(), new UIMessageOverlayPanel(
                UIKeys.TEXTURES_EXPORT_OVERLAY_TITLE,
                UIKeys.TEXTURES_EXPORT_OVERLAY_ERROR.format(file.getName())
            ));
        }
    }

    private void remove()
    {
        if (this.panel.getLink() == null)
        {
            return;
        }

        BBSModClient.getTextures().textures.remove(this.panel.getLink()).delete();

        this.panel.pickLink(this.textures.list.getCurrentFirst());
    }

    private void extractFrames()
    {
        UIOverlay.addOverlay(this.getContext(), new UITextureExtractOverlayPanel(this.panel), 200, 231);
    }

    @Override
    protected void renderBackground(UIContext context)
    {
        super.renderBackground(context);

        if (this.linkLinear)
        {
            this.linear.area.render(context.batcher, Colors.A50 | BBSSettings.primaryColor.get());
        }
    }
}