package mchorse.bbs_mod.ui.film.screenplay;

import mchorse.bbs_mod.BBSMod;
import mchorse.bbs_mod.BBSSettings;
import mchorse.bbs_mod.audio.ColorCode;
import mchorse.bbs_mod.audio.SoundPlayer;
import mchorse.bbs_mod.audio.Wave;
import mchorse.bbs_mod.audio.Waveform;
import mchorse.bbs_mod.audio.wav.WaveWriter;
import mchorse.bbs_mod.camera.clips.misc.AudioClientClip;
import mchorse.bbs_mod.camera.clips.misc.SubtitleClip;
import mchorse.bbs_mod.camera.clips.misc.VoicelineClip;
import mchorse.bbs_mod.camera.utils.TimeUtils;
import mchorse.bbs_mod.data.DataToString;
import mchorse.bbs_mod.data.types.ListType;
import mchorse.bbs_mod.film.Film;
import mchorse.bbs_mod.film.Fountain;
import mchorse.bbs_mod.film.tts.ElevenLabsAPI;
import mchorse.bbs_mod.film.tts.ElevenLabsResult;
import mchorse.bbs_mod.graphics.window.Window;
import mchorse.bbs_mod.resources.Link;
import mchorse.bbs_mod.ui.Keys;
import mchorse.bbs_mod.ui.UIKeys;
import mchorse.bbs_mod.ui.film.UIClipsPanel;
import mchorse.bbs_mod.ui.film.UIFilmPanel;
import mchorse.bbs_mod.ui.framework.UIContext;
import mchorse.bbs_mod.ui.framework.elements.UIElement;
import mchorse.bbs_mod.ui.framework.elements.buttons.UIIcon;
import mchorse.bbs_mod.ui.framework.elements.input.text.highlighting.SyntaxStyle;
import mchorse.bbs_mod.ui.framework.elements.overlay.UIMessageFolderOverlayPanel;
import mchorse.bbs_mod.ui.framework.elements.overlay.UIOverlay;
import mchorse.bbs_mod.ui.framework.elements.overlay.UITextareaOverlayPanel;
import mchorse.bbs_mod.ui.utils.UI;
import mchorse.bbs_mod.ui.utils.icons.Icons;
import mchorse.bbs_mod.utils.MathUtils;
import mchorse.bbs_mod.utils.Pair;
import mchorse.bbs_mod.utils.clips.Clip;
import mchorse.bbs_mod.utils.colors.Colors;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.system.MemoryUtil;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public class UIScreenplayEditor extends UIElement
{
    public UIElement masterBar;
    public UIAudioPlayer master;
    public UIIcon generate;
    public UIIcon subtitles;
    public UIIcon save;

    public UIClipsPanel editor;

    private UIFilmPanel panel;
    private Film film;
    private SyntaxStyle style = new SyntaxStyle();
    private List<ColorCode> colorCodes = new ArrayList<>();

    public UIScreenplayEditor(UIFilmPanel panel)
    {
        this.panel = panel;

        this.master = new UIAudioPlayer();
        this.generate = new UIIcon(Icons.SOUND, (b) -> this.generate());
        this.generate.tooltip(UIKeys.VOICE_LINE_COMPILE);
        this.subtitles = new UIIcon(Icons.FONT, (b) -> this.generateSubtitles());
        this.subtitles.tooltip(UIKeys.VOICE_LINE_SUBTITLES);
        this.save = new UIIcon(Icons.SAVED, (b) -> this.saveAudio());
        this.save.tooltip(UIKeys.VOICE_LINE_SAVE);
        this.masterBar = UI.row(this.master, this.save, this.subtitles, this.generate);
        this.masterBar.relative(this).x(10).y(10).w(1F, -20).h(20);

        this.editor = new UIClipsPanel(panel, BBSMod.getFactoryScreenplayClips()).target(this.panel.editArea);
        this.editor.relative(this).y(40).w(1F).h(1F, -40);
        this.editor.clips.context((menu) ->
        {
            if (this.film == null)
            {
                return;
            }

            menu.action(Icons.FILE, UIKeys.VOICE_LINE_FOUNTAIN, () ->
            {
                UITextareaOverlayPanel overlayPanel = new UITextareaOverlayPanel(
                    UIKeys.VOICE_LINE_FOUNTAIN_TITLE,
                    UIKeys.VOICE_LINE_FOUNTAIN_DESCRIPTION,
                    this::parseFountain
                );

                UIOverlay.addOverlay(this.getContext(), overlayPanel);
            });
        });

        this.add(this.editor, this.masterBar);
        this.markContainer();

        this.keys().register(Keys.PLAUSE, () -> this.master.play.clickItself());
    }

    private void parseFountain(String str)
    {
        List<VoicelineClip> clips = new ArrayList<>();
        int layer = this.film.voiceLines.getTopLayer();

        for (Fountain.Reply reply : Fountain.parseReplies(str))
        {
            VoicelineClip clip = new VoicelineClip();

            clip.layer.set(layer);
            clip.voice.set(reply.name.toLowerCase());
            clip.content.set(reply.reply);

            clips.add(clip);
        }

        AtomicInteger newOffset = new AtomicInteger();
        UIContext context = this.getContext();

        ElevenLabsAPI.generateStandard(context, UIFilmPanel.getVoiceLines().getFolder(), clips, (result) ->
        {
            /* Post runnable is necessary because callback is calling from non-main thread */
            MinecraftClient.getInstance().execute(() ->
            {
                if (result.clip != null && result.status == ElevenLabsResult.Status.GENERATED)
                {
                    Pair<Wave, Waveform> pair = UIFilmPanel.getVoiceLines().get(result.clip);
                    int duration = (int) (pair.a.getDuration() * 20);

                    result.clip.tick.set(newOffset.get());
                    result.clip.duration.set(duration);

                    newOffset.set(newOffset.get() + duration);
                    this.film.voiceLines.addClip(result.clip);
                }
            });
        });
    }

    public void setCursor(int ticks)
    {
        SoundPlayer player = this.master.getPlayer();

        if (player != null)
        {
            player.setPlaybackPosition(ticks / 20F);
        }
    }

    private void generate()
    {
        if (this.master.getPlayer() != null)
        {
            this.master.getPlayer().stop();
        }

        Wave lastWave = null;
        float total = this.film.voiceLines.calculateDuration() / 20F;
        Map<VoicelineClip, Wave> map = new HashMap<>();

        this.colorCodes.clear();

        for (Clip aClip : this.film.voiceLines.get())
        {
            if (!(aClip instanceof VoicelineClip))
            {
                continue;
            }

            VoicelineClip clip = (VoicelineClip) aClip;
            Wave wave = UIFilmPanel.getVoiceLines().get(clip).a;

            if (wave != null)
            {
                map.put(clip, wave);
            }
        }

        if (map.isEmpty())
        {
            return;
        }

        int totalBytes = (int) (total * map.values().iterator().next().byteRate);
        byte[] bytes = new byte[totalBytes + totalBytes % 2];
        ByteBuffer buffer = MemoryUtil.memAlloc(2);

        for (Clip aClip : this.film.voiceLines.get())
        {
            if (!(aClip instanceof VoicelineClip))
            {
                continue;
            }

            VoicelineClip clip = (VoicelineClip) aClip;

            try
            {
                float time = clip.tick.get() / 20F;
                float duration = clip.duration.get() / 20F;
                Wave wave = map.get(clip);

                int offset = (int) (time * wave.byteRate);
                int length = (int) (duration * wave.byteRate);

                offset -= offset % 2;

                length = Math.min(wave.data.length, MathUtils.clamp(length, 0, bytes.length - offset));
                length -= length % 2;

                for (int i = 0; i < length; i += 2)
                {
                    buffer.position(0);
                    buffer.put(wave.data[i]);
                    buffer.put(wave.data[i + 1]);

                    int waveShort = buffer.getShort(0);

                    buffer.position(0);
                    buffer.put(bytes[offset + i]);
                    buffer.put(bytes[offset + i + 1]);

                    int bytesShort = buffer.getShort(0);
                    int finalShort = waveShort + bytesShort;

                    buffer.putShort(0, (short) MathUtils.clamp(finalShort, Short.MIN_VALUE, Short.MAX_VALUE));

                    bytes[offset + i + 1] = buffer.get(1);
                    bytes[offset + i] =     buffer.get(0);
                }

                this.colorCodes.add(new ColorCode(time, time + duration, BBSSettings.elevenVoiceColors.getColor(clip.voice.get())));

                lastWave = wave;
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }
        }

        MemoryUtil.memFree(buffer);

        if (lastWave != null)
        {
            Wave wave = new Wave(lastWave.audioFormat, lastWave.numChannels, lastWave.sampleRate, lastWave.bitsPerSample, bytes);

            this.master.loadAudio(wave, this.colorCodes);

            SoundPlayer player = this.master.getPlayer();

            player.play();
            player.setPlaybackPosition(this.editor.getCursor() / 20F);
            player.pause();
        }
    }

    private void generateSubtitles()
    {
        Film data = this.panel.getData();
        int layer = data.camera.getTopLayer();

        for (Clip aClip : this.film.voiceLines.get())
        {
            if (!(aClip instanceof VoicelineClip))
            {
                continue;
            }

            VoicelineClip action = (VoicelineClip) aClip;
            SubtitleClip clip = new SubtitleClip();

            clip.title.set(action.content.get());
            clip.tick.set(action.tick.get());
            clip.duration.set(action.duration.get());
            clip.layer.set(layer + 1);
            clip.color.set(BBSSettings.elevenVoiceColors.getColor(action.voice.get()));

            data.camera.addClip(clip);
        }

        this.panel.showPanel(this.panel.cameraEditor);
    }

    private void saveAudio()
    {
        Wave wave = this.master.getWave();

        if (wave == null)
        {
            return;
        }

        try
        {
            File folder = BBSMod.getAudioFolder();
            String filename = this.panel.getData().getId() + ".wav";

            WaveWriter.write(new File(folder, filename), wave);
            ListType colorCodes = new ListType();

            for (ColorCode colorCode : this.colorCodes)
            {
                colorCodes.add(colorCode.toData());
            }

            DataToString.writeSilently(new File(folder, filename + ".json"), colorCodes, true);

            if (Window.isCtrlPressed())
            {
                Film film = this.panel.getData();
                int layer = film.camera.getTopLayer();

                AudioClientClip clip = new AudioClientClip();

                clip.duration.set((int) (wave.getDuration() * 20));
                clip.layer.set(layer + 1);
                clip.audio.set(Link.assets("audio/" + filename));

                film.camera.addClip(clip);
                this.panel.showPanel(this.panel.cameraEditor);
            }
            else
            {
                UIOverlay.addOverlay(this.getContext(), new UIMessageFolderOverlayPanel(
                    UIKeys.VOICE_LINE_SAVE_AUDIO_TITLE,
                    UIKeys.VOICE_LINE_SAVE_AUDIO_DESCRIPTION.format(filename),
                    folder
                ));
            }
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public void setFilm(Film film)
    {
        this.film = film;

        this.fillData();
    }

    private void fillData()
    {
        this.editor.setClips(this.film.voiceLines);

        this.resize();
    }

    @Override
    public void render(UIContext context)
    {
        SoundPlayer player = this.master.getPlayer();

        if (player != null)
        {
            this.panel.getRunner().ticks = TimeUtils.toTick(player.getPlaybackPosition());
        }

        this.area.render(context.batcher, this.style.background | Colors.A100);

        super.render(context);
    }
}