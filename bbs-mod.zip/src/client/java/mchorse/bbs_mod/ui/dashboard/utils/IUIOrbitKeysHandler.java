package mchorse.bbs_mod.ui.dashboard.utils;

import mchorse.bbs_mod.ui.framework.UIContext;

public interface IUIOrbitKeysHandler
{
    public boolean handleKeyPressed(UIContext context);
}